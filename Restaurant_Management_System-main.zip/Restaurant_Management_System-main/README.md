# Restaurant_Management_System

The above files includes all the templets used with backend programming, front-end connectivity and SQL connection given.

It includes the presentation of the whole project and documentation or the snyopsis of the project along with necessary content
